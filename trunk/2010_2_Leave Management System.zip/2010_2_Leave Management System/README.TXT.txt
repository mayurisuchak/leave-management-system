Dear Student,

Welcome to eProjects

It gives us immense pleasure to address you about eProjects. This is a new way of learning, which would value add the
existing course material that has been provided to you.

You are requested to read the PDF document carefully, it contains the eproject specifcation to be done by you.

You can download the acrobat reader from the link: http://www.adobe.com/products/acrobat/readstep2.html
						   ----------------------------------------------------

Also We will like to put forward some important guidelines which should be kept in mind throughout the eproject schedule.

1. Eproject Status report:

   You need to send us 2 status report mails in 10 days interval from the start date of the project. The status report
   format is attached with the eproject specification.Along with the status report, you should also send the review document.    Review document should include all the project related information indicating the progress of the project. Status mail        without review document will not be considered as valid. Review document should include the details like analysis,            design/Flowcharts, database design, E-R diagrams/DFDs,user manual/installation guide and Screenshots(Include whichever is applicable) with brief explanation. Also note that this is part of eproject execution process and carry 10 marks    in the final result of the eproject. Status report should be sent one per group at eprojects@aptech.ac.in 
                                                                                   ----------------------
   Also you can send your doubts / clarification or any additional inputs required to complete your eproject any time during     the project planning and execution.

2. Eproject submission:

    YOU SHOULD SUBMIT THE PROJECT AS PER THE SCHEDULE PROVIDED TO YOU.

    You need to upload working application and eproject report(documentation) separately.

  i. You need to keep all your project source code files and database backup/script into a single folder, zip that folder and      upload the zipped file for submission. Note that code files updated separately will not be evaluated. The name of zipped folder should be teamname_source.zip
                 --------------------
  ii.Also keep the eproject report / documentation and feedback form into a single folder zip the same and upload for           eproject documentation. The name of folder should be teamname_report.zip
                                                       -------------------

3. You can upload the eproject anytime before your eproject submission date. Incase if you want to update your submission,       you can do the same by uploaing the latest project files; but this can be done only on or before the eproject submission      date. Along with the eproject you should also submit the feedback form. The feedback form should be submitted by each         individual in the team.
   
4. Incase your project size is more than 5 MB then you need to send the eproject through the below mentioned site(s) as a ZIP file:
   
http://www.filefactory.com

http://www.yousendit.com

After uploading the file. A link for downloading the file will be generated. You are supposed to copy the link and send through email along with the details of the team to eProjects@aptech.ac.in

   ZIP file should comprise of the following:

   i.   All source code files zipped into a single folder
   ii.  database backup / script
   iii. Project report.
   iv.  Feedback forms duly filled by all the team members
   v.   Names, Roll Numbers of all the team members and centre name should be tagged on the CD.



